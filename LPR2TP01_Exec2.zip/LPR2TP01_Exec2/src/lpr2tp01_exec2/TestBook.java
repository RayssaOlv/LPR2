/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lpr2tp01_exec2;

/**
 *
 * @author aluno
 */
public class TestBook {
    public static void main(String[] args) {
        //Teste 1
        Author[] authors = new Author[2];
        authors[0] = new Author(
                "Autor 01",
                "autor01@somewhere.com.br",
                'm'
        );
        authors[1] = new Author(
                "Autor 02",
                "autor02@nowhere.com.br",
                'm'
        );

        System.out.println("===== TESTE DA CLASSE AUTHOR =====");
        System.out.println("Nome do primeiro autor: "
                + authors[0].getName());
        System.out.println("E-mail do primeiro autor: "
                + authors[0].getEmail());
        System.out.println("Gênero do primeiro autor: "
                + authors[0].getGender());
        System.out.println("Autor antes de alterar o e-mail:");
        System.out.println(authors[0]);

        authors[0].setEmail("autor01_novo@email.com");
        System.out.println("Autor depois de alterar o e-mail:");
        System.out.println(authors[0]);

        System.out.println();
        System.out.println("===== TESTE DA CLASSE BOOK =====");

        // Teste de preço e quantidade
        Book testeBook = new Book(
                "Java for Dummy",
                authors,
                19.99,
                99
        );

        System.out.println("Nome do livro: " + testeBook.getName());
        System.out.println("Preço inicial: " + testeBook.getPrice());
        System.out.println("Quantidade inicial: " + testeBook.getQty());
        System.out.println("Nomes dos autores: "
                + testeBook.getAuthorNames());
        System.out.println("Autores do livro:");
        for (Author author : testeBook.getAuthors()) {
            System.out.println(author);
        }
        System.out.println("Livro criado:");
        System.out.println(testeBook);

        // Teste dos setters de preço e quantidade.
        testeBook.setPrice(24.90);
        testeBook.setQty(50);

        System.out.println();
        System.out.println("Depois de usar setPrice() e setQty():");
        System.out.println("Novo preço: " + testeBook.getPrice());
        System.out.println("Nova quantidade: " + testeBook.getQty());
        System.out.println(testeBook);

        // Teste do construtor que inicia a quantidade com zero
        Book bookSemQuantidade = new Book(
                "Livro de Teste",
                authors,
                10.00
        );

        System.out.println();
        System.out.println("Livro criado com o construtor de três parâmetros:");
        System.out.println(bookSemQuantidade);
        System.out.println("A quantidade inicial deve ser 0.");
    } 
}
