/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lpr2tp01_exec2;
import java.util.*;
/**
 *
 * @author aluno
 */
public class Book {
    private final String name;
    private final Author[] authors;
    private double price;
    private int qty;

    public Book(String name, Author[] authors, double price) {
        this(name, authors, price, 0);
    }


    public Book(String name, Author[] authors, double price, int qty) {
        if (authors == null) {
            throw new IllegalArgumentException("O array de autores não pode ser nulo.");
        }

        this.name = name;
        this.authors = Arrays.copyOf(authors, authors.length);
        this.price = price;
        this.qty = qty;
    }

    public String getName() {
        return name;
    }


    public Author[] getAuthors() {
        return Arrays.copyOf(authors, authors.length);
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getPrice() {
        return price;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public String getAuthorNames() {
        StringBuilder names = new StringBuilder();

        for (int i = 0; i < authors.length; i++) {
            if (i > 0) {
                names.append(",");
            }
            names.append(authors[i].getName());
        }

        return names.toString();
    }

    @Override
    public String toString() {
        StringBuilder authorsText = new StringBuilder();

        for (int i = 0; i < authors.length; i++) {
            if (i > 0) {
                authorsText.append(",");
            }
            authorsText.append(authors[i]);
        }

        return "Book[name=" + name
                + ",authors={" + authorsText
                + "},price=" + price
                + ",qty=" + qty + "]";
    }
}
